module.exports = function (ctx, next) {
    ctx.state.data = { msg: 'Hello World' }
}
